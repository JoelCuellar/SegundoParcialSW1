package com.acme.demo.web;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.NoSuchElementException;

import com.acme.demo.domain.Order;
import com.acme.demo.service.OrderService;

@CrossOrigin
@RestController
@RequestMapping("/api/order")
public class OrderController {
  private final OrderService svc;
  public OrderController(OrderService svc) { this.svc = svc; }

  @GetMapping
  public List<Order> list() { return svc.findAll(); }

  @GetMapping("/{id}")
  public Order get(@PathVariable java.util.UUID id) {
    return svc.findById(id).orElseThrow(() -> new NoSuchElementException("Not found"));
  }

  @PostMapping
  @ResponseStatus(HttpStatus.CREATED)
  public Order create(@RequestBody Order body) { return svc.save(body); }

  @PutMapping("/{id}")
  public Order update(@PathVariable java.util.UUID id, @RequestBody Order body) {
    return svc.save(body);
  }

  @DeleteMapping("/{id}")
  @ResponseStatus(HttpStatus.NO_CONTENT)
  public void delete(@PathVariable java.util.UUID id) { svc.delete(id); }
}
