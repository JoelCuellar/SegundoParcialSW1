package com.acme.demo.web;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.NoSuchElementException;

import com.acme.demo.domain.Clase1ClaseJoin;
import com.acme.demo.service.Clase1ClaseJoinService;

@CrossOrigin
@RestController
@RequestMapping("/api/clase1ClaseJoin")
public class Clase1ClaseJoinController {
  private final Clase1ClaseJoinService svc;
  public Clase1ClaseJoinController(Clase1ClaseJoinService svc) { this.svc = svc; }

  @GetMapping
  public List<Clase1ClaseJoin> list() { return svc.findAll(); }

  @GetMapping("/{id}")
  public Clase1ClaseJoin get(@PathVariable java.util.UUID id) {
    return svc.findById(id).orElseThrow(() -> new NoSuchElementException("Not found"));
  }

  @PostMapping
  @ResponseStatus(HttpStatus.CREATED)
  public Clase1ClaseJoin create(@RequestBody Clase1ClaseJoin body) { return svc.save(body); }

  @PutMapping("/{id}")
  public Clase1ClaseJoin update(@PathVariable java.util.UUID id, @RequestBody Clase1ClaseJoin body) {
    return svc.save(body);
  }

  @DeleteMapping("/{id}")
  @ResponseStatus(HttpStatus.NO_CONTENT)
  public void delete(@PathVariable java.util.UUID id) { svc.delete(id); }
}
