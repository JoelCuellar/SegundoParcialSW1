package com.acme.demo.service;

import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
import com.acme.demo.domain.Order;
import com.acme.demo.repository.OrderRepository;

@Service
public class OrderService {
  private final OrderRepository repo;
  public OrderService(OrderRepository repo) { this.repo = repo; }

  public List<Order> findAll() { return repo.findAll(); }
  public Optional<Order> findById(java.util.UUID id) { return repo.findById(id); }
  public Order save(Order e) { return repo.save(e); }
  public void delete(java.util.UUID id) { repo.deleteById(id); }
}
