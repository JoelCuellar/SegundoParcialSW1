package com.acme.demo.domain;

import jakarta.persistence.*;
import lombok.*;
import java.io.Serializable;





import java.time.Instant;
import java.util.UUID;
import java.util.Set;

@Entity
@Table(name = "user")

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class User implements Serializable {

  @Id
  @Column(name = "id", nullable = false)
  private java.util.UUID id;
  
  @Column(name = "email", nullable = false, unique = true)
  private java.lang.String email;
  
  @Column(name = "created_at", nullable = false)
  private java.time.Instant created_at;

    @OneToMany(mappedBy = "user", cascade = CascadeType.MERGE)
  private Set<Order> orders;

    @OneToMany(mappedBy = "user", cascade = CascadeType.MERGE)
  private Set<Address> address;

    @OneToMany(mappedBy = "user")
  private Set<Clase1> clase1s;

}
