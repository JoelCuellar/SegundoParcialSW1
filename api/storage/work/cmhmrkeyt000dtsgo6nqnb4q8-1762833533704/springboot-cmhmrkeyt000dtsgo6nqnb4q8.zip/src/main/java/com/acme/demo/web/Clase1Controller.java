package com.acme.demo.web;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.NoSuchElementException;

import com.acme.demo.domain.Clase1;
import com.acme.demo.service.Clase1Service;

@CrossOrigin
@RestController
@RequestMapping("/api/clase1")
public class Clase1Controller {
  private final Clase1Service svc;
  public Clase1Controller(Clase1Service svc) { this.svc = svc; }

  @GetMapping
  public List<Clase1> list() { return svc.findAll(); }

  @GetMapping("/{id}")
  public Clase1 get(@PathVariable java.util.UUID id) {
    return svc.findById(id).orElseThrow(() -> new NoSuchElementException("Not found"));
  }

  @PostMapping
  @ResponseStatus(HttpStatus.CREATED)
  public Clase1 create(@RequestBody Clase1 body) { return svc.save(body); }

  @PutMapping("/{id}")
  public Clase1 update(@PathVariable java.util.UUID id, @RequestBody Clase1 body) {
    return svc.save(body);
  }

  @DeleteMapping("/{id}")
  @ResponseStatus(HttpStatus.NO_CONTENT)
  public void delete(@PathVariable java.util.UUID id) { svc.delete(id); }
}
