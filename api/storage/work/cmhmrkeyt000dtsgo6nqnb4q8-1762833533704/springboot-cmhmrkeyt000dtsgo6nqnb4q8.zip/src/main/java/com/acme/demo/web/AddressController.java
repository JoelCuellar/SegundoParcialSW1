package com.acme.demo.web;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.NoSuchElementException;

import com.acme.demo.domain.Address;
import com.acme.demo.service.AddressService;

@CrossOrigin
@RestController
@RequestMapping("/api/address")
public class AddressController {
  private final AddressService svc;
  public AddressController(AddressService svc) { this.svc = svc; }

  @GetMapping
  public List<Address> list() { return svc.findAll(); }

  @GetMapping("/{id}")
  public Address get(@PathVariable java.util.UUID id) {
    return svc.findById(id).orElseThrow(() -> new NoSuchElementException("Not found"));
  }

  @PostMapping
  @ResponseStatus(HttpStatus.CREATED)
  public Address create(@RequestBody Address body) { return svc.save(body); }

  @PutMapping("/{id}")
  public Address update(@PathVariable java.util.UUID id, @RequestBody Address body) {
    return svc.save(body);
  }

  @DeleteMapping("/{id}")
  @ResponseStatus(HttpStatus.NO_CONTENT)
  public void delete(@PathVariable java.util.UUID id) { svc.delete(id); }
}
