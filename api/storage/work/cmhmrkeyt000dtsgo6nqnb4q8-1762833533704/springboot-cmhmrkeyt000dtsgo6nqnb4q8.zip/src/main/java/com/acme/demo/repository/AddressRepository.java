package com.acme.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.acme.demo.domain.Address;

public interface AddressRepository extends JpaRepository<Address, java.util.UUID> {}
