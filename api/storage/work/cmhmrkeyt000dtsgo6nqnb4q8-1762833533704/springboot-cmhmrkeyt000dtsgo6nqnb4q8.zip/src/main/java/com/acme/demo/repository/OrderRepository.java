package com.acme.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.acme.demo.domain.Order;

public interface OrderRepository extends JpaRepository<Order, java.util.UUID> {}
