package com.acme.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.acme.demo.domain.PedidoProductoJoin;

public interface PedidoProductoJoinRepository extends JpaRepository<PedidoProductoJoin, java.util.UUID> {}
