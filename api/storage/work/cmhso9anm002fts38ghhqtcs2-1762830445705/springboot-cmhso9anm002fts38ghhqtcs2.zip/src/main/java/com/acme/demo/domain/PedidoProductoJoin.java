package com.acme.demo.domain;

import jakarta.persistence.*;
import lombok.*;
import java.io.Serializable;




import java.util.UUID;


@Entity
@Table(name = "pedidoproductojoin")

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class PedidoProductoJoin implements Serializable {

  @Id
  @Column(name = "productoId", nullable = false)
  private java.util.UUID productoId;
  @Id
  @Column(name = "pedidoId", nullable = false)
  private java.util.UUID pedidoId;

}
