package com.acme.demo.service;

import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
import com.acme.demo.domain.Catalogo;
import com.acme.demo.repository.CatalogoRepository;

@Service
public class CatalogoService {
  private final CatalogoRepository repo;
  public CatalogoService(CatalogoRepository repo) { this.repo = repo; }

  public List<Catalogo> findAll() { return repo.findAll(); }
  public Optional<Catalogo> findById(java.lang.Integer id) { return repo.findById(id); }
  public Catalogo save(Catalogo e) { return repo.save(e); }
  public void delete(java.lang.Integer id) { repo.deleteById(id); }
}
