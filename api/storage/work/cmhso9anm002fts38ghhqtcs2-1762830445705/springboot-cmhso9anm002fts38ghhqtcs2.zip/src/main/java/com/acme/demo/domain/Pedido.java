package com.acme.demo.domain;

import jakarta.persistence.*;
import lombok.*;
import java.io.Serializable;













import java.util.Set;

@Entity
@Table(name = "pedido")

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Pedido implements Serializable {

  @Id
  @Column(name = "id", nullable = false)
  private java.lang.Integer id;
  
  @Column(name = "total", nullable = false)
  private java.lang.Integer total;
  
  @Column(name = "estado", nullable = false)
  private java.lang.Integer estado;
  
  @Column(name = "tipo_entrega", nullable = false)
  private java.lang.Integer tipo_entrega;
  
  @Column(name = "fecha_pedido", nullable = false)
  private java.lang.Integer fecha_pedido;
  
  @Column(name = "fecha_entrega", nullable = false)
  private java.lang.Integer fecha_entrega;

    @ManyToMany(mappedBy = "pedidos")
  private Set<Producto> productos;

    @ManyToOne
  @JoinColumn(name = "delivery_id", referencedColumnName = "id")
  private Delivery delivery;

    @ManyToOne
  @JoinColumn(name = "cliente_id", referencedColumnName = "id")
  private Cliente cliente;

    @OneToOne
  @JoinColumn(name = "nota_venta_id", referencedColumnName = "id")
  private Nota_venta nota_venta;

}
