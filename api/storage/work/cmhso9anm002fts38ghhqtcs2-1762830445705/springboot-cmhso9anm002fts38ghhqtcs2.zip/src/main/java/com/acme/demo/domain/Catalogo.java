package com.acme.demo.domain;

import jakarta.persistence.*;
import lombok.*;
import java.io.Serializable;









import java.util.Set;

@Entity
@Table(name = "catalogo")

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Catalogo implements Serializable {

  @Id
  @Column(name = "id", nullable = false)
  private java.lang.Integer id;
  
  @Column(name = "nombre", nullable = false)
  private java.lang.Integer nombre;
  
  @Column(name = "descripcion", nullable = false)
  private java.lang.Integer descripcion;
  
  @Column(name = "activo", nullable = false)
  private java.lang.Integer activo;

    @ManyToMany(mappedBy = "catalogos")
  private Set<Producto> productos;

}
