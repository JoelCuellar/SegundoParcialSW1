package com.acme.demo.web;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.NoSuchElementException;

import com.acme.demo.domain.detalle_pedido;
import com.acme.demo.service.detalle_pedidoService;

@CrossOrigin
@RestController
@RequestMapping("/api/detalle_pedido")
public class detalle_pedidoController {
  private final detalle_pedidoService svc;
  public detalle_pedidoController(detalle_pedidoService svc) { this.svc = svc; }

  @GetMapping
  public List<detalle_pedido> list() { return svc.findAll(); }

  @GetMapping("/{id}")
  public detalle_pedido get(@PathVariable java.lang.Integer id) {
    return svc.findById(id).orElseThrow(() -> new NoSuchElementException("Not found"));
  }

  @PostMapping
  @ResponseStatus(HttpStatus.CREATED)
  public detalle_pedido create(@RequestBody detalle_pedido body) { return svc.save(body); }

  @PutMapping("/{id}")
  public detalle_pedido update(@PathVariable java.lang.Integer id, @RequestBody detalle_pedido body) {
    return svc.save(body);
  }

  @DeleteMapping("/{id}")
  @ResponseStatus(HttpStatus.NO_CONTENT)
  public void delete(@PathVariable java.lang.Integer id) { svc.delete(id); }
}
