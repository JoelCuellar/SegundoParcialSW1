package com.acme.demo.service;

import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
import com.acme.demo.domain.CatalogoProductoJoin;
import com.acme.demo.repository.CatalogoProductoJoinRepository;

@Service
public class CatalogoProductoJoinService {
  private final CatalogoProductoJoinRepository repo;
  public CatalogoProductoJoinService(CatalogoProductoJoinRepository repo) { this.repo = repo; }

  public List<CatalogoProductoJoin> findAll() { return repo.findAll(); }
  public Optional<CatalogoProductoJoin> findById(java.util.UUID id) { return repo.findById(id); }
  public CatalogoProductoJoin save(CatalogoProductoJoin e) { return repo.save(e); }
  public void delete(java.util.UUID id) { repo.deleteById(id); }
}
