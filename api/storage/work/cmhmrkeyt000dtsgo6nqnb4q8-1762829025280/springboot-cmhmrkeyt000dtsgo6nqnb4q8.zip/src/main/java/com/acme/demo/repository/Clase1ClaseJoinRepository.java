package com.acme.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.acme.demo.domain.Clase1ClaseJoin;

public interface Clase1ClaseJoinRepository extends JpaRepository<Clase1ClaseJoin, java.util.UUID> {}
