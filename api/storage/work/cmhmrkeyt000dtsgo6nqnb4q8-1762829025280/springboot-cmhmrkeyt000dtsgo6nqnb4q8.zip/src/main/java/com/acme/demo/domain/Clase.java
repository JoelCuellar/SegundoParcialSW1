package com.acme.demo.domain;

import jakarta.persistence.*;
import lombok.*;
import java.io.Serializable;


import java.util.UUID;
import java.util.Set;

@Entity
@Table(name = "clase")

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Clase implements Serializable {

  @Id
  @Column(name = "id", nullable = false)
  private java.util.UUID id;

    @OneToMany(mappedBy = "clase", cascade = CascadeType.MERGE)
  private Set<Clase1ClaseJoin> clase1ClaseJoins;

    @ManyToOne
  @JoinColumn(name = "clase1_id", referencedColumnName = "id")
  private Clase1 clase1;

}
