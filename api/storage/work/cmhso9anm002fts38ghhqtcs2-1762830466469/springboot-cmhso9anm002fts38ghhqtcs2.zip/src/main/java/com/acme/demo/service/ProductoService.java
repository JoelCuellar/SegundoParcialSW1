package com.acme.demo.service;

import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
import com.acme.demo.domain.Producto;
import com.acme.demo.repository.ProductoRepository;

@Service
public class ProductoService {
  private final ProductoRepository repo;
  public ProductoService(ProductoRepository repo) { this.repo = repo; }

  public List<Producto> findAll() { return repo.findAll(); }
  public Optional<Producto> findById(java.lang.Integer id) { return repo.findById(id); }
  public Producto save(Producto e) { return repo.save(e); }
  public void delete(java.lang.Integer id) { repo.deleteById(id); }
}
