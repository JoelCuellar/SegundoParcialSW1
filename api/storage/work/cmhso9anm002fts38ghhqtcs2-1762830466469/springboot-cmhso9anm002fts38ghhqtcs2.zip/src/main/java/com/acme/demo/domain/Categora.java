package com.acme.demo.domain;

import jakarta.persistence.*;
import lombok.*;
import java.io.Serializable;





import java.util.Set;

@Entity
@Table(name = "categora")

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Categora implements Serializable {

  @Id
  @Column(name = "id", nullable = false)
  private java.lang.Integer id;
  
  @Column(name = "nombre", nullable = false)
  private java.lang.Integer nombre;

    @OneToMany(mappedBy = "categora")
  private Set<Producto> productos;

}
