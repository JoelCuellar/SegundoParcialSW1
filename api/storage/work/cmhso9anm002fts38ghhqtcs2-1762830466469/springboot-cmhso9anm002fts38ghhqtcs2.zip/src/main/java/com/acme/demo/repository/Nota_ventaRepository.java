package com.acme.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.acme.demo.domain.Nota_venta;

public interface Nota_ventaRepository extends JpaRepository<Nota_venta, java.lang.Integer> {}
