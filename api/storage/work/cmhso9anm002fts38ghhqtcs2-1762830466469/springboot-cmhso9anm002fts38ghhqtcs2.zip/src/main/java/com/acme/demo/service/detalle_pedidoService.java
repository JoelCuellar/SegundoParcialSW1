package com.acme.demo.service;

import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
import com.acme.demo.domain.detalle_pedido;
import com.acme.demo.repository.detalle_pedidoRepository;

@Service
public class detalle_pedidoService {
  private final detalle_pedidoRepository repo;
  public detalle_pedidoService(detalle_pedidoRepository repo) { this.repo = repo; }

  public List<detalle_pedido> findAll() { return repo.findAll(); }
  public Optional<detalle_pedido> findById(java.lang.Integer id) { return repo.findById(id); }
  public detalle_pedido save(detalle_pedido e) { return repo.save(e); }
  public void delete(java.lang.Integer id) { repo.deleteById(id); }
}
