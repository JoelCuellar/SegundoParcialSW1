package com.acme.demo.web;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.NoSuchElementException;

import com.acme.demo.domain.CatalogoProductoJoin;
import com.acme.demo.service.CatalogoProductoJoinService;

@CrossOrigin
@RestController
@RequestMapping("/api/catalogoProductoJoin")
public class CatalogoProductoJoinController {
  private final CatalogoProductoJoinService svc;
  public CatalogoProductoJoinController(CatalogoProductoJoinService svc) { this.svc = svc; }

  @GetMapping
  public List<CatalogoProductoJoin> list() { return svc.findAll(); }

  @GetMapping("/{id}")
  public CatalogoProductoJoin get(@PathVariable java.util.UUID id) {
    return svc.findById(id).orElseThrow(() -> new NoSuchElementException("Not found"));
  }

  @PostMapping
  @ResponseStatus(HttpStatus.CREATED)
  public CatalogoProductoJoin create(@RequestBody CatalogoProductoJoin body) { return svc.save(body); }

  @PutMapping("/{id}")
  public CatalogoProductoJoin update(@PathVariable java.util.UUID id, @RequestBody CatalogoProductoJoin body) {
    return svc.save(body);
  }

  @DeleteMapping("/{id}")
  @ResponseStatus(HttpStatus.NO_CONTENT)
  public void delete(@PathVariable java.util.UUID id) { svc.delete(id); }
}
