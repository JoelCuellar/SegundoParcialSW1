package com.acme.demo.web;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.NoSuchElementException;

import com.acme.demo.domain.Delivery;
import com.acme.demo.service.DeliveryService;

@CrossOrigin
@RestController
@RequestMapping("/api/delivery")
public class DeliveryController {
  private final DeliveryService svc;
  public DeliveryController(DeliveryService svc) { this.svc = svc; }

  @GetMapping
  public List<Delivery> list() { return svc.findAll(); }

  @GetMapping("/{id}")
  public Delivery get(@PathVariable java.lang.Integer id) {
    return svc.findById(id).orElseThrow(() -> new NoSuchElementException("Not found"));
  }

  @PostMapping
  @ResponseStatus(HttpStatus.CREATED)
  public Delivery create(@RequestBody Delivery body) { return svc.save(body); }

  @PutMapping("/{id}")
  public Delivery update(@PathVariable java.lang.Integer id, @RequestBody Delivery body) {
    return svc.save(body);
  }

  @DeleteMapping("/{id}")
  @ResponseStatus(HttpStatus.NO_CONTENT)
  public void delete(@PathVariable java.lang.Integer id) { svc.delete(id); }
}
