package com.acme.demo.web;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.NoSuchElementException;

import com.acme.demo.domain.producto_catalogo;
import com.acme.demo.service.producto_catalogoService;

@CrossOrigin
@RestController
@RequestMapping("/api/producto_catalogo")
public class producto_catalogoController {
  private final producto_catalogoService svc;
  public producto_catalogoController(producto_catalogoService svc) { this.svc = svc; }

  @GetMapping
  public List<producto_catalogo> list() { return svc.findAll(); }

  @GetMapping("/{id}")
  public producto_catalogo get(@PathVariable java.util.UUID id) {
    return svc.findById(id).orElseThrow(() -> new NoSuchElementException("Not found"));
  }

  @PostMapping
  @ResponseStatus(HttpStatus.CREATED)
  public producto_catalogo create(@RequestBody producto_catalogo body) { return svc.save(body); }

  @PutMapping("/{id}")
  public producto_catalogo update(@PathVariable java.util.UUID id, @RequestBody producto_catalogo body) {
    return svc.save(body);
  }

  @DeleteMapping("/{id}")
  @ResponseStatus(HttpStatus.NO_CONTENT)
  public void delete(@PathVariable java.util.UUID id) { svc.delete(id); }
}
