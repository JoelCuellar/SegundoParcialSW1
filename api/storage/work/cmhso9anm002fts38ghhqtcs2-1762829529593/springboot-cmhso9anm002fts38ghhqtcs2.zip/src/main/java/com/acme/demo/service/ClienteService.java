package com.acme.demo.service;

import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
import com.acme.demo.domain.Cliente;
import com.acme.demo.repository.ClienteRepository;

@Service
public class ClienteService {
  private final ClienteRepository repo;
  public ClienteService(ClienteRepository repo) { this.repo = repo; }

  public List<Cliente> findAll() { return repo.findAll(); }
  public Optional<Cliente> findById(java.lang.Integer id) { return repo.findById(id); }
  public Cliente save(Cliente e) { return repo.save(e); }
  public void delete(java.lang.Integer id) { repo.deleteById(id); }
}
