package com.acme.demo.web;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.NoSuchElementException;

import com.acme.demo.domain.Producto;
import com.acme.demo.service.ProductoService;

@CrossOrigin
@RestController
@RequestMapping("/api/producto")
public class ProductoController {
  private final ProductoService svc;
  public ProductoController(ProductoService svc) { this.svc = svc; }

  @GetMapping
  public List<Producto> list() { return svc.findAll(); }

  @GetMapping("/{id}")
  public Producto get(@PathVariable java.lang.Integer id) {
    return svc.findById(id).orElseThrow(() -> new NoSuchElementException("Not found"));
  }

  @PostMapping
  @ResponseStatus(HttpStatus.CREATED)
  public Producto create(@RequestBody Producto body) { return svc.save(body); }

  @PutMapping("/{id}")
  public Producto update(@PathVariable java.lang.Integer id, @RequestBody Producto body) {
    return svc.save(body);
  }

  @DeleteMapping("/{id}")
  @ResponseStatus(HttpStatus.NO_CONTENT)
  public void delete(@PathVariable java.lang.Integer id) { svc.delete(id); }
}
