package com.acme.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.acme.demo.domain.Catalogo;

public interface CatalogoRepository extends JpaRepository<Catalogo, java.lang.Integer> {}
