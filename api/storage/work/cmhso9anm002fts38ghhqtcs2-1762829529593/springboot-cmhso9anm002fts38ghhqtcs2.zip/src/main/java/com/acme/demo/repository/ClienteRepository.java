package com.acme.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.acme.demo.domain.Cliente;

public interface ClienteRepository extends JpaRepository<Cliente, java.lang.Integer> {}
