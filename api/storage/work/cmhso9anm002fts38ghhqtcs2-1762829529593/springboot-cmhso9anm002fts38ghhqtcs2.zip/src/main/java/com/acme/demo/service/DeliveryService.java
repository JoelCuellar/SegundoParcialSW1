package com.acme.demo.service;

import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
import com.acme.demo.domain.Delivery;
import com.acme.demo.repository.DeliveryRepository;

@Service
public class DeliveryService {
  private final DeliveryRepository repo;
  public DeliveryService(DeliveryRepository repo) { this.repo = repo; }

  public List<Delivery> findAll() { return repo.findAll(); }
  public Optional<Delivery> findById(java.lang.Integer id) { return repo.findById(id); }
  public Delivery save(Delivery e) { return repo.save(e); }
  public void delete(java.lang.Integer id) { repo.deleteById(id); }
}
