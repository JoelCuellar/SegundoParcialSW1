package com.acme.demo.domain;

import jakarta.persistence.*;
import lombok.*;
import java.io.Serializable;













@Entity
@Table(name = "detalle_pedido")

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class detalle_pedido implements Serializable {

  @Id
  @Column(name = "id", nullable = false)
  private java.lang.Integer id;
  
  @Column(name = "cantidad", nullable = false)
  private java.lang.Integer cantidad;
  
  @Column(name = "precio_unitario", nullable = false)
  private java.lang.Integer precio_unitario;
  
  @Column(name = "productoId", nullable = false)
  private java.lang.String productoId;
  
  @Column(name = "pedidoId", nullable = false)
  private java.lang.String pedidoId;

}
