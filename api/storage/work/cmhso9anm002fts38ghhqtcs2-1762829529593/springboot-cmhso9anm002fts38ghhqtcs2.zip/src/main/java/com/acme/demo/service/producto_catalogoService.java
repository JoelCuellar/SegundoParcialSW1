package com.acme.demo.service;

import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
import com.acme.demo.domain.producto_catalogo;
import com.acme.demo.repository.producto_catalogoRepository;

@Service
public class producto_catalogoService {
  private final producto_catalogoRepository repo;
  public producto_catalogoService(producto_catalogoRepository repo) { this.repo = repo; }

  public List<producto_catalogo> findAll() { return repo.findAll(); }
  public Optional<producto_catalogo> findById(java.util.UUID id) { return repo.findById(id); }
  public producto_catalogo save(producto_catalogo e) { return repo.save(e); }
  public void delete(java.util.UUID id) { repo.deleteById(id); }
}
