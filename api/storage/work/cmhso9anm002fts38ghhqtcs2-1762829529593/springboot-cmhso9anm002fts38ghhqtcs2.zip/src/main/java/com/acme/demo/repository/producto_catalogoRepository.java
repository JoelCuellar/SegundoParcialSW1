package com.acme.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.acme.demo.domain.producto_catalogo;

public interface producto_catalogoRepository extends JpaRepository<producto_catalogo, java.util.UUID> {}
