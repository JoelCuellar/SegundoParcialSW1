package com.acme.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.acme.demo.domain.CatalogoProductoJoin;

public interface CatalogoProductoJoinRepository extends JpaRepository<CatalogoProductoJoin, java.util.UUID> {}
