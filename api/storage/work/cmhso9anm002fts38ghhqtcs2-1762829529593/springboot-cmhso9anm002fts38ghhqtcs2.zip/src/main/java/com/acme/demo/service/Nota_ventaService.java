package com.acme.demo.service;

import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
import com.acme.demo.domain.Nota_venta;
import com.acme.demo.repository.Nota_ventaRepository;

@Service
public class Nota_ventaService {
  private final Nota_ventaRepository repo;
  public Nota_ventaService(Nota_ventaRepository repo) { this.repo = repo; }

  public List<Nota_venta> findAll() { return repo.findAll(); }
  public Optional<Nota_venta> findById(java.lang.Integer id) { return repo.findById(id); }
  public Nota_venta save(Nota_venta e) { return repo.save(e); }
  public void delete(java.lang.Integer id) { repo.deleteById(id); }
}
