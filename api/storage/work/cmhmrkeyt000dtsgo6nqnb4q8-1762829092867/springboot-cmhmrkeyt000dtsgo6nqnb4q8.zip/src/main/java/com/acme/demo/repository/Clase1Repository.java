package com.acme.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.acme.demo.domain.Clase1;

public interface Clase1Repository extends JpaRepository<Clase1, java.util.UUID> {}
