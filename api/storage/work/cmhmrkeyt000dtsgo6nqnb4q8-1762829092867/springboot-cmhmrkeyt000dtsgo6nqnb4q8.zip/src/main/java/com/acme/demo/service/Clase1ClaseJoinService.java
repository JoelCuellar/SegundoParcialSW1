package com.acme.demo.service;

import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
import com.acme.demo.domain.Clase1ClaseJoin;
import com.acme.demo.repository.Clase1ClaseJoinRepository;

@Service
public class Clase1ClaseJoinService {
  private final Clase1ClaseJoinRepository repo;
  public Clase1ClaseJoinService(Clase1ClaseJoinRepository repo) { this.repo = repo; }

  public List<Clase1ClaseJoin> findAll() { return repo.findAll(); }
  public Optional<Clase1ClaseJoin> findById(java.util.UUID id) { return repo.findById(id); }
  public Clase1ClaseJoin save(Clase1ClaseJoin e) { return repo.save(e); }
  public void delete(java.util.UUID id) { repo.deleteById(id); }
}
