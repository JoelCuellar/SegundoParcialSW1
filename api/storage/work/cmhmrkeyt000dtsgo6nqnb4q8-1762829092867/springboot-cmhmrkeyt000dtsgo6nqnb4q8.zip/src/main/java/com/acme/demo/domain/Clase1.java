package com.acme.demo.domain;

import jakarta.persistence.*;
import lombok.*;
import java.io.Serializable;


import java.util.UUID;
import java.util.Set;

@Entity
@Table(name = "clase1")

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Clase1 implements Serializable {

  @Id
  @Column(name = "id", nullable = false)
  private java.util.UUID id;

    @OneToMany(mappedBy = "clase1")
  private Set<Address> address;

    @OneToMany(mappedBy = "clase1")
  private Set<Clase1ClaseJoin> clase1ClaseJoins;

    @OneToMany(mappedBy = "clase1")
  private Set<Clase> clases;

    @ManyToOne
  @JoinColumn(name = "user_id", referencedColumnName = "id")
  private User user;

    @ManyToOne
  @JoinColumn(name = "order_id", referencedColumnName = "id")
  private Order order;

}
