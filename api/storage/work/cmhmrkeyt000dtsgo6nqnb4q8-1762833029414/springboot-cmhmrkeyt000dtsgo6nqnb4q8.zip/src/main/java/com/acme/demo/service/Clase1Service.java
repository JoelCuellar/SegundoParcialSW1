package com.acme.demo.service;

import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
import com.acme.demo.domain.Clase1;
import com.acme.demo.repository.Clase1Repository;

@Service
public class Clase1Service {
  private final Clase1Repository repo;
  public Clase1Service(Clase1Repository repo) { this.repo = repo; }

  public List<Clase1> findAll() { return repo.findAll(); }
  public Optional<Clase1> findById(java.util.UUID id) { return repo.findById(id); }
  public Clase1 save(Clase1 e) { return repo.save(e); }
  public void delete(java.util.UUID id) { repo.deleteById(id); }
}
