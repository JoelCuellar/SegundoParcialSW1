CREATE TABLE IF NOT EXISTS "user" (
  "id" uuid NOT NULL,
  "email" varchar(255) NOT NULL UNIQUE,
  "created_at" timestamp NOT NULL,
  PRIMARY KEY ("id")
);

CREATE TABLE IF NOT EXISTS "order" (
  "id" uuid NOT NULL,
  "total" varchar(255) NOT NULL,
  "user_id" uuid NOT NULL,
  "userId" uuid NOT NULL,
  PRIMARY KEY ("id")
);

CREATE TABLE IF NOT EXISTS "address" (
  "id" uuid NOT NULL,
  "user_id" uuid NOT NULL,
  "line1" varchar(255) NOT NULL,
  "city" varchar(255) NOT NULL,
  "userId" uuid NOT NULL,
  PRIMARY KEY ("id")
);

CREATE TABLE IF NOT EXISTS "clase1" (
  "id" uuid NOT NULL,
  PRIMARY KEY ("id")
);

CREATE TABLE IF NOT EXISTS "clase" (
  "id" uuid NOT NULL,
  PRIMARY KEY ("id")
);

CREATE TABLE IF NOT EXISTS "clase1clasejoin" (
  "clase1Id" uuid NOT NULL,
  "claseId" uuid NOT NULL,
  PRIMARY KEY ("clase1Id")
);

ALTER TABLE "order" ADD COLUMN IF NOT EXISTS "user_id" uuid;
ALTER TABLE "order" ADD CONSTRAINT "fk_order_user"
  FOREIGN KEY ("user_id") REFERENCES "user"("id");
ALTER TABLE "address" ADD COLUMN IF NOT EXISTS "user_id" uuid;
ALTER TABLE "address" ADD CONSTRAINT "fk_address_user"
  FOREIGN KEY ("user_id") REFERENCES "user"("id");
ALTER TABLE "address" ADD COLUMN IF NOT EXISTS "clase1_id" uuid;
ALTER TABLE "address" ADD CONSTRAINT "fk_address_clase1"
  FOREIGN KEY ("clase1_id") REFERENCES "clase1"("id");
ALTER TABLE "clase1clasejoin" ADD COLUMN IF NOT EXISTS "clase1_id" uuid;
ALTER TABLE "clase1clasejoin" ADD CONSTRAINT "fk_clase1clasejoin_clase1"
  FOREIGN KEY ("clase1_id") REFERENCES "clase1"("id");
ALTER TABLE "clase1clasejoin" ADD COLUMN IF NOT EXISTS "clase_id" uuid;
ALTER TABLE "clase1clasejoin" ADD CONSTRAINT "fk_clase1clasejoin_clase"
  FOREIGN KEY ("clase_id") REFERENCES "clase"("id");
ALTER TABLE "clase" ADD COLUMN IF NOT EXISTS "clase1_id" uuid;
ALTER TABLE "clase" ADD CONSTRAINT "fk_clase_clase1"
  FOREIGN KEY ("clase1_id") REFERENCES "clase1"("id");
ALTER TABLE "clase1" ADD COLUMN IF NOT EXISTS "user_id" uuid;
ALTER TABLE "clase1" ADD CONSTRAINT "fk_clase1_user"
  FOREIGN KEY ("user_id") REFERENCES "user"("id");
ALTER TABLE "clase1" ADD COLUMN IF NOT EXISTS "order_id" uuid;
ALTER TABLE "clase1" ADD CONSTRAINT "fk_clase1_order"
  FOREIGN KEY ("order_id") REFERENCES "order"("id");
ALTER TABLE "order" ADD COLUMN IF NOT EXISTS "clase1clasejoin_id" uuid;
ALTER TABLE "order" ADD CONSTRAINT "fk_order_clase1clasejoin"
  FOREIGN KEY ("clase1clasejoin_id") REFERENCES "clase1clasejoin"("clase1Id");
