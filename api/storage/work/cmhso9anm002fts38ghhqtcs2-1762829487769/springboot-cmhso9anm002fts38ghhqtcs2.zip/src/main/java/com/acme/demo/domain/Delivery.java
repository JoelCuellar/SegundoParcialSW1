package com.acme.demo.domain;

import jakarta.persistence.*;
import lombok.*;
import java.io.Serializable;





















import java.util.Set;

@Entity
@Table(name = "delivery")

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Delivery implements Serializable {

  @Id
  @Column(name = "id", nullable = false)
  private java.lang.Integer id;
  
  @Column(name = "repartidor", nullable = false)
  private java.lang.Integer repartidor;
  
  @Column(name = "direccion_entrega", nullable = false)
  private java.lang.Integer direccion_entrega;
  
  @Column(name = "referencia_entrega", nullable = false)
  private java.lang.Integer referencia_entrega;
  
  @Column(name = "telefono_entrega", nullable = false)
  private java.lang.Integer telefono_entrega;
  
  @Column(name = "estado", nullable = false)
  private java.lang.Integer estado;
  
  @Column(name = "fecha_asignacion", nullable = false)
  private java.lang.Integer fecha_asignacion;
  
  @Column(name = "fecha_entrega", nullable = false)
  private java.lang.Integer fecha_entrega;
  
  @Column(name = "observaciones", nullable = false)
  private java.lang.Integer observaciones;
  
  @Column(name = "costo", nullable = false)
  private java.lang.Integer costo;

    @OneToMany(mappedBy = "delivery")
  private Set<Pedido> pedidos;

}
