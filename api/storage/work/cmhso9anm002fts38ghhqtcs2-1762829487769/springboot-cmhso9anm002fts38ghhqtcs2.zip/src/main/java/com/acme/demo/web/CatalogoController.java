package com.acme.demo.web;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.NoSuchElementException;

import com.acme.demo.domain.Catalogo;
import com.acme.demo.service.CatalogoService;

@CrossOrigin
@RestController
@RequestMapping("/api/catalogo")
public class CatalogoController {
  private final CatalogoService svc;
  public CatalogoController(CatalogoService svc) { this.svc = svc; }

  @GetMapping
  public List<Catalogo> list() { return svc.findAll(); }

  @GetMapping("/{id}")
  public Catalogo get(@PathVariable java.lang.Integer id) {
    return svc.findById(id).orElseThrow(() -> new NoSuchElementException("Not found"));
  }

  @PostMapping
  @ResponseStatus(HttpStatus.CREATED)
  public Catalogo create(@RequestBody Catalogo body) { return svc.save(body); }

  @PutMapping("/{id}")
  public Catalogo update(@PathVariable java.lang.Integer id, @RequestBody Catalogo body) {
    return svc.save(body);
  }

  @DeleteMapping("/{id}")
  @ResponseStatus(HttpStatus.NO_CONTENT)
  public void delete(@PathVariable java.lang.Integer id) { svc.delete(id); }
}
