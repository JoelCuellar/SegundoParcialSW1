package com.acme.demo.domain;

import jakarta.persistence.*;
import lombok.*;
import java.io.Serializable;











import java.util.Set;

@Entity
@Table(name = "cliente")

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Cliente implements Serializable {

  @Id
  @Column(name = "id", nullable = false)
  private java.lang.Integer id;
  
  @Column(name = "nombre", nullable = false)
  private java.lang.Integer nombre;
  
  @Column(name = "telefono", nullable = false)
  private java.lang.Integer telefono;
  
  @Column(name = "direccion", nullable = false)
  private java.lang.Integer direccion;
  
  @Column(name = "referencia", nullable = false)
  private java.lang.Integer referencia;

    @OneToMany(mappedBy = "cliente")
  private Set<Pedido> pedidos;

}
