package com.acme.demo.web;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.NoSuchElementException;

import com.acme.demo.domain.Nota_venta;
import com.acme.demo.service.Nota_ventaService;

@CrossOrigin
@RestController
@RequestMapping("/api/nota_venta")
public class Nota_ventaController {
  private final Nota_ventaService svc;
  public Nota_ventaController(Nota_ventaService svc) { this.svc = svc; }

  @GetMapping
  public List<Nota_venta> list() { return svc.findAll(); }

  @GetMapping("/{id}")
  public Nota_venta get(@PathVariable java.lang.Integer id) {
    return svc.findById(id).orElseThrow(() -> new NoSuchElementException("Not found"));
  }

  @PostMapping
  @ResponseStatus(HttpStatus.CREATED)
  public Nota_venta create(@RequestBody Nota_venta body) { return svc.save(body); }

  @PutMapping("/{id}")
  public Nota_venta update(@PathVariable java.lang.Integer id, @RequestBody Nota_venta body) {
    return svc.save(body);
  }

  @DeleteMapping("/{id}")
  @ResponseStatus(HttpStatus.NO_CONTENT)
  public void delete(@PathVariable java.lang.Integer id) { svc.delete(id); }
}
