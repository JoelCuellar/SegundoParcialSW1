package com.acme.demo.service;

import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
import com.acme.demo.domain.Pedido;
import com.acme.demo.repository.PedidoRepository;

@Service
public class PedidoService {
  private final PedidoRepository repo;
  public PedidoService(PedidoRepository repo) { this.repo = repo; }

  public List<Pedido> findAll() { return repo.findAll(); }
  public Optional<Pedido> findById(java.lang.Integer id) { return repo.findById(id); }
  public Pedido save(Pedido e) { return repo.save(e); }
  public void delete(java.lang.Integer id) { repo.deleteById(id); }
}
