package com.acme.demo.web;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.NoSuchElementException;

import com.acme.demo.domain.Pedido;
import com.acme.demo.service.PedidoService;

@CrossOrigin
@RestController
@RequestMapping("/api/pedido")
public class PedidoController {
  private final PedidoService svc;
  public PedidoController(PedidoService svc) { this.svc = svc; }

  @GetMapping
  public List<Pedido> list() { return svc.findAll(); }

  @GetMapping("/{id}")
  public Pedido get(@PathVariable java.lang.Integer id) {
    return svc.findById(id).orElseThrow(() -> new NoSuchElementException("Not found"));
  }

  @PostMapping
  @ResponseStatus(HttpStatus.CREATED)
  public Pedido create(@RequestBody Pedido body) { return svc.save(body); }

  @PutMapping("/{id}")
  public Pedido update(@PathVariable java.lang.Integer id, @RequestBody Pedido body) {
    return svc.save(body);
  }

  @DeleteMapping("/{id}")
  @ResponseStatus(HttpStatus.NO_CONTENT)
  public void delete(@PathVariable java.lang.Integer id) { svc.delete(id); }
}
