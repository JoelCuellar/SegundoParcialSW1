package com.acme.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.acme.demo.domain.detalle_pedido;

public interface detalle_pedidoRepository extends JpaRepository<detalle_pedido, java.lang.Integer> {}
