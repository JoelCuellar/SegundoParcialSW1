package com.acme.demo.domain;

import jakarta.persistence.*;
import lombok.*;
import java.io.Serializable;








import java.util.UUID;


@Entity
@Table(name = "producto_catalogo")

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class producto_catalogo implements Serializable {

  @Id
  @Column(name = "id", nullable = false, unique = true)
  private java.util.UUID id;
  
  @Column(name = "orden", nullable = false)
  private java.lang.Integer orden;
  
  @Column(name = "productoId", nullable = false)
  private java.lang.String productoId;
  
  @Column(name = "catalogoId", nullable = false)
  private java.lang.String catalogoId;

}
