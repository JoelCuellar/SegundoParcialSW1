package com.acme.demo.domain;

import jakarta.persistence.*;
import lombok.*;
import java.io.Serializable;









import java.util.Set;

@Entity
@Table(name = "producto")

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Producto implements Serializable {

  @Id
  @Column(name = "id", nullable = false)
  private java.lang.Integer id;
  
  @Column(name = "nombre", nullable = false)
  private java.lang.Integer nombre;
  
  @Column(name = "descripcion", nullable = false)
  private java.lang.Integer descripcion;
  
  @Column(name = "precio", nullable = false)
  private java.lang.Integer precio;

    @ManyToOne
  @JoinColumn(name = "categora_id", referencedColumnName = "id")
  private Categora categora;

    @ManyToMany
  @JoinTable(
    name = "catalogo_producto",
    joinColumns = @JoinColumn(name = "producto_id"),
    inverseJoinColumns = @JoinColumn(name = "catalogo_id")
  )
  private Set<Catalogo> catalogos;

    @ManyToMany
  @JoinTable(
    name = "pedido_producto",
    joinColumns = @JoinColumn(name = "producto_id"),
    inverseJoinColumns = @JoinColumn(name = "pedido_id")
  )
  private Set<Pedido> pedidos;

}
