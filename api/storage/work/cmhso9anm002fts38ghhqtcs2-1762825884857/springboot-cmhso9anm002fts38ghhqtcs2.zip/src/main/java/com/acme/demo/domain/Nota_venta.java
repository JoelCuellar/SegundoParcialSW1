package com.acme.demo.domain;

import jakarta.persistence.*;
import lombok.*;
import java.io.Serializable;

















@Entity
@Table(name = "nota_venta")

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Nota_venta implements Serializable {

  @Id
  @Column(name = "id", nullable = false)
  private java.lang.Integer id;
  
  @Column(name = "numero_nota", nullable = false)
  private java.lang.Integer numero_nota;
  
  @Column(name = "fecha_emision", nullable = false)
  private java.lang.Integer fecha_emision;
  
  @Column(name = "subtotal", nullable = false)
  private java.lang.Integer subtotal;
  
  @Column(name = "descuento", nullable = false)
  private java.lang.Integer descuento;
  
  @Column(name = "costo_delivery", nullable = false)
  private java.lang.Integer costo_delivery;
  
  @Column(name = "total", nullable = false)
  private java.lang.Integer total;

    @OneToOne(mappedBy = "nota_venta")
  private Pedido pedido;

}
