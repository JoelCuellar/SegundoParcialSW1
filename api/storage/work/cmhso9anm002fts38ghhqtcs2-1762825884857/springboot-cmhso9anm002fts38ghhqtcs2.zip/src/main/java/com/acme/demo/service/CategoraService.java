package com.acme.demo.service;

import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
import com.acme.demo.domain.Categora;
import com.acme.demo.repository.CategoraRepository;

@Service
public class CategoraService {
  private final CategoraRepository repo;
  public CategoraService(CategoraRepository repo) { this.repo = repo; }

  public List<Categora> findAll() { return repo.findAll(); }
  public Optional<Categora> findById(java.lang.Integer id) { return repo.findById(id); }
  public Categora save(Categora e) { return repo.save(e); }
  public void delete(java.lang.Integer id) { repo.deleteById(id); }
}
