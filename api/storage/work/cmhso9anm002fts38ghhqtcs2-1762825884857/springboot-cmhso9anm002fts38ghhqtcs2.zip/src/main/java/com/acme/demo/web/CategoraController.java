package com.acme.demo.web;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.NoSuchElementException;

import com.acme.demo.domain.Categora;
import com.acme.demo.service.CategoraService;

@CrossOrigin
@RestController
@RequestMapping("/api/categora")
public class CategoraController {
  private final CategoraService svc;
  public CategoraController(CategoraService svc) { this.svc = svc; }

  @GetMapping
  public List<Categora> list() { return svc.findAll(); }

  @GetMapping("/{id}")
  public Categora get(@PathVariable java.lang.Integer id) {
    return svc.findById(id).orElseThrow(() -> new NoSuchElementException("Not found"));
  }

  @PostMapping
  @ResponseStatus(HttpStatus.CREATED)
  public Categora create(@RequestBody Categora body) { return svc.save(body); }

  @PutMapping("/{id}")
  public Categora update(@PathVariable java.lang.Integer id, @RequestBody Categora body) {
    return svc.save(body);
  }

  @DeleteMapping("/{id}")
  @ResponseStatus(HttpStatus.NO_CONTENT)
  public void delete(@PathVariable java.lang.Integer id) { svc.delete(id); }
}
