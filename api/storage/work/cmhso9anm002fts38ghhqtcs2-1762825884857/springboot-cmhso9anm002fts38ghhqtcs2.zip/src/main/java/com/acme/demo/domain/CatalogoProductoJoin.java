package com.acme.demo.domain;

import jakarta.persistence.*;
import lombok.*;
import java.io.Serializable;




import java.util.UUID;


@Entity
@Table(name = "catalogoproductojoin")

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class CatalogoProductoJoin implements Serializable {

  @Id
  @Column(name = "productoId", nullable = false)
  private java.util.UUID productoId;
  @Id
  @Column(name = "catalogoId", nullable = false)
  private java.util.UUID catalogoId;

}
