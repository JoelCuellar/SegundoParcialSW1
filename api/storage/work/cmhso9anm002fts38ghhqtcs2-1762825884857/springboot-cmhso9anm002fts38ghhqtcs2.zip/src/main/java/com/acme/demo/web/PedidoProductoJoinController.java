package com.acme.demo.web;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.NoSuchElementException;

import com.acme.demo.domain.PedidoProductoJoin;
import com.acme.demo.service.PedidoProductoJoinService;

@CrossOrigin
@RestController
@RequestMapping("/api/pedidoProductoJoin")
public class PedidoProductoJoinController {
  private final PedidoProductoJoinService svc;
  public PedidoProductoJoinController(PedidoProductoJoinService svc) { this.svc = svc; }

  @GetMapping
  public List<PedidoProductoJoin> list() { return svc.findAll(); }

  @GetMapping("/{id}")
  public PedidoProductoJoin get(@PathVariable java.util.UUID id) {
    return svc.findById(id).orElseThrow(() -> new NoSuchElementException("Not found"));
  }

  @PostMapping
  @ResponseStatus(HttpStatus.CREATED)
  public PedidoProductoJoin create(@RequestBody PedidoProductoJoin body) { return svc.save(body); }

  @PutMapping("/{id}")
  public PedidoProductoJoin update(@PathVariable java.util.UUID id, @RequestBody PedidoProductoJoin body) {
    return svc.save(body);
  }

  @DeleteMapping("/{id}")
  @ResponseStatus(HttpStatus.NO_CONTENT)
  public void delete(@PathVariable java.util.UUID id) { svc.delete(id); }
}
