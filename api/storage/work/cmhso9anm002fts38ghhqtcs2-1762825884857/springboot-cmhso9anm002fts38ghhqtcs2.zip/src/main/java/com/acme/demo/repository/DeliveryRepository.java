package com.acme.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.acme.demo.domain.Delivery;

public interface DeliveryRepository extends JpaRepository<Delivery, java.lang.Integer> {}
