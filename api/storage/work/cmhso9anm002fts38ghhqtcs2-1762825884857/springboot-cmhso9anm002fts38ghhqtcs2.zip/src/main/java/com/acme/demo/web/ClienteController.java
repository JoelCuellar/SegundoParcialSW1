package com.acme.demo.web;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.NoSuchElementException;

import com.acme.demo.domain.Cliente;
import com.acme.demo.service.ClienteService;

@CrossOrigin
@RestController
@RequestMapping("/api/cliente")
public class ClienteController {
  private final ClienteService svc;
  public ClienteController(ClienteService svc) { this.svc = svc; }

  @GetMapping
  public List<Cliente> list() { return svc.findAll(); }

  @GetMapping("/{id}")
  public Cliente get(@PathVariable java.lang.Integer id) {
    return svc.findById(id).orElseThrow(() -> new NoSuchElementException("Not found"));
  }

  @PostMapping
  @ResponseStatus(HttpStatus.CREATED)
  public Cliente create(@RequestBody Cliente body) { return svc.save(body); }

  @PutMapping("/{id}")
  public Cliente update(@PathVariable java.lang.Integer id, @RequestBody Cliente body) {
    return svc.save(body);
  }

  @DeleteMapping("/{id}")
  @ResponseStatus(HttpStatus.NO_CONTENT)
  public void delete(@PathVariable java.lang.Integer id) { svc.delete(id); }
}
