package com.acme.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.acme.demo.domain.Categora;

public interface CategoraRepository extends JpaRepository<Categora, java.lang.Integer> {}
