CREATE TABLE IF NOT EXISTS "categora" (
  "id" integer NOT NULL,
  "nombre" integer NOT NULL,
  PRIMARY KEY ("id")
);

CREATE TABLE IF NOT EXISTS "producto" (
  "id" integer NOT NULL,
  "nombre" integer NOT NULL,
  "descripcion" integer NOT NULL,
  "precio" integer NOT NULL,
  PRIMARY KEY ("id")
);

CREATE TABLE IF NOT EXISTS "catalogo" (
  "id" integer NOT NULL,
  "nombre" integer NOT NULL,
  "descripcion" integer NOT NULL,
  "activo" integer NOT NULL,
  PRIMARY KEY ("id")
);

CREATE TABLE IF NOT EXISTS "producto_catalogo" (
  "id" uuid NOT NULL UNIQUE,
  "orden" integer NOT NULL,
  "productoId" varchar(255) NOT NULL,
  "catalogoId" varchar(255) NOT NULL,
  PRIMARY KEY ("id")
);

CREATE TABLE IF NOT EXISTS "detalle_pedido" (
  "id" integer NOT NULL,
  "cantidad" integer NOT NULL,
  "precio_unitario" integer NOT NULL,
  "productoId" varchar(255) NOT NULL,
  "pedidoId" varchar(255) NOT NULL,
  PRIMARY KEY ("id")
);

CREATE TABLE IF NOT EXISTS "pedido" (
  "id" integer NOT NULL,
  "total" integer NOT NULL,
  "estado" integer NOT NULL,
  "tipo_entrega" integer NOT NULL,
  "fecha_pedido" integer NOT NULL,
  "fecha_entrega" integer NOT NULL,
  PRIMARY KEY ("id")
);

CREATE TABLE IF NOT EXISTS "delivery" (
  "id" integer NOT NULL,
  "repartidor" integer NOT NULL,
  "direccion_entrega" integer NOT NULL,
  "referencia_entrega" integer NOT NULL,
  "telefono_entrega" integer NOT NULL,
  "estado" integer NOT NULL,
  "fecha_asignacion" integer NOT NULL,
  "fecha_entrega" integer NOT NULL,
  "observaciones" integer NOT NULL,
  "costo" integer NOT NULL,
  PRIMARY KEY ("id")
);

CREATE TABLE IF NOT EXISTS "cliente" (
  "id" integer NOT NULL,
  "nombre" integer NOT NULL,
  "telefono" integer NOT NULL,
  "direccion" integer NOT NULL,
  "referencia" integer NOT NULL,
  PRIMARY KEY ("id")
);

CREATE TABLE IF NOT EXISTS "nota_venta" (
  "id" integer NOT NULL,
  "numero_nota" integer NOT NULL,
  "fecha_emision" integer NOT NULL,
  "subtotal" integer NOT NULL,
  "descuento" integer NOT NULL,
  "costo_delivery" integer NOT NULL,
  "total" integer NOT NULL,
  PRIMARY KEY ("id")
);

CREATE TABLE IF NOT EXISTS "catalogoproductojoin" (
  "productoId" uuid NOT NULL,
  "catalogoId" uuid NOT NULL,
  PRIMARY KEY ("productoId")
);

CREATE TABLE IF NOT EXISTS "pedidoproductojoin" (
  "productoId" uuid NOT NULL,
  "pedidoId" uuid NOT NULL,
  PRIMARY KEY ("productoId")
);

ALTER TABLE "pedido" ADD COLUMN IF NOT EXISTS "delivery_id" integer;
ALTER TABLE "pedido" ADD CONSTRAINT "fk_pedido_delivery"
  FOREIGN KEY ("delivery_id") REFERENCES "delivery"("id");
ALTER TABLE "pedido" ADD COLUMN IF NOT EXISTS "cliente_id" integer;
ALTER TABLE "pedido" ADD CONSTRAINT "fk_pedido_cliente"
  FOREIGN KEY ("cliente_id") REFERENCES "cliente"("id");
ALTER TABLE "pedido" ADD COLUMN IF NOT EXISTS "nota_venta_id" integer;
ALTER TABLE "pedido" ADD CONSTRAINT "fk_pedido_nota_venta"
  FOREIGN KEY ("nota_venta_id") REFERENCES "nota_venta"("id");
