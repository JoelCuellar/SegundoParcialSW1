package com.acme.demo.service;

import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
import com.acme.demo.domain.User;
import com.acme.demo.repository.UserRepository;

@Service
public class UserService {
  private final UserRepository repo;
  public UserService(UserRepository repo) { this.repo = repo; }

  public List<User> findAll() { return repo.findAll(); }
  public Optional<User> findById(java.util.UUID id) { return repo.findById(id); }
  public User save(User e) { return repo.save(e); }
  public void delete(java.util.UUID id) { repo.deleteById(id); }
}
