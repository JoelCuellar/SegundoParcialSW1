package com.acme.demo.domain;

import jakarta.persistence.*;
import lombok.*;
import java.io.Serializable;








import java.util.UUID;
import java.util.Set;

@Entity
@Table(name = "order")

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Order implements Serializable {

  @Id
  @Column(name = "id", nullable = false)
  private java.util.UUID id;
  
  @Column(name = "total", nullable = false)
  private java.lang.String total;
  
  @Column(name = "user_id", nullable = false)
  private java.util.UUID user_id;
  
  @Column(name = "userId", nullable = false)
  private java.util.UUID userId;

    @ManyToOne(cascade = CascadeType.MERGE)
  @JoinColumn(name = "user_id", referencedColumnName = "id")
  private User user;

    @OneToMany(mappedBy = "order")
  private Set<Clase1> clase1s;

    @ManyToOne
  @JoinColumn(name = "clase1clasejoin_id", referencedColumnName = "clase1Id")
  private Clase1ClaseJoin clase1ClaseJoin;

}
