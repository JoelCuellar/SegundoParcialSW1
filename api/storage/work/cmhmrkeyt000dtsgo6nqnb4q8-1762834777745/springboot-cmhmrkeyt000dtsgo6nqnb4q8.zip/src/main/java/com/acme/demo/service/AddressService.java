package com.acme.demo.service;

import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
import com.acme.demo.domain.Address;
import com.acme.demo.repository.AddressRepository;

@Service
public class AddressService {
  private final AddressRepository repo;
  public AddressService(AddressRepository repo) { this.repo = repo; }

  public List<Address> findAll() { return repo.findAll(); }
  public Optional<Address> findById(java.util.UUID id) { return repo.findById(id); }
  public Address save(Address e) { return repo.save(e); }
  public void delete(java.util.UUID id) { repo.deleteById(id); }
}
