package com.acme.demo.domain;

import jakarta.persistence.*;
import lombok.*;
import java.io.Serializable;










import java.util.UUID;


@Entity
@Table(name = "address")

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Address implements Serializable {

  @Id
  @Column(name = "id", nullable = false)
  private java.util.UUID id;
  
  @Column(name = "user_id", nullable = false)
  private java.util.UUID user_id;
  
  @Column(name = "line1", nullable = false)
  private java.lang.String line1;
  
  @Column(name = "city", nullable = false)
  private java.lang.String city;
  
  @Column(name = "userId", nullable = false)
  private java.util.UUID userId;

    @ManyToOne(cascade = CascadeType.MERGE)
  @JoinColumn(name = "user_id", referencedColumnName = "id")
  private User user;

    @ManyToOne
  @JoinColumn(name = "clase1_id", referencedColumnName = "id")
  private Clase1 clase1;

}
