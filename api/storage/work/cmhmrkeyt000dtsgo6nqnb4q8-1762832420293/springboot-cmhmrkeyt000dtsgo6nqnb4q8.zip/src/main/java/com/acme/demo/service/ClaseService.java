package com.acme.demo.service;

import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
import com.acme.demo.domain.Clase;
import com.acme.demo.repository.ClaseRepository;

@Service
public class ClaseService {
  private final ClaseRepository repo;
  public ClaseService(ClaseRepository repo) { this.repo = repo; }

  public List<Clase> findAll() { return repo.findAll(); }
  public Optional<Clase> findById(java.util.UUID id) { return repo.findById(id); }
  public Clase save(Clase e) { return repo.save(e); }
  public void delete(java.util.UUID id) { repo.deleteById(id); }
}
