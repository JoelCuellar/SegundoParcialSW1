package com.acme.demo.web;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.NoSuchElementException;

import com.acme.demo.domain.User;
import com.acme.demo.service.UserService;

@CrossOrigin
@RestController
@RequestMapping("/api/user")
public class UserController {
  private final UserService svc;
  public UserController(UserService svc) { this.svc = svc; }

  @GetMapping
  public List<User> list() { return svc.findAll(); }

  @GetMapping("/{id}")
  public User get(@PathVariable java.util.UUID id) {
    return svc.findById(id).orElseThrow(() -> new NoSuchElementException("Not found"));
  }

  @PostMapping
  @ResponseStatus(HttpStatus.CREATED)
  public User create(@RequestBody User body) { return svc.save(body); }

  @PutMapping("/{id}")
  public User update(@PathVariable java.util.UUID id, @RequestBody User body) {
    return svc.save(body);
  }

  @DeleteMapping("/{id}")
  @ResponseStatus(HttpStatus.NO_CONTENT)
  public void delete(@PathVariable java.util.UUID id) { svc.delete(id); }
}
