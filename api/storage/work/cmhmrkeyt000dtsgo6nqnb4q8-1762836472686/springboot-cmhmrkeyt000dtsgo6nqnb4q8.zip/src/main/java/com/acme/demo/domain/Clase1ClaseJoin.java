package com.acme.demo.domain;

import jakarta.persistence.*;
import lombok.*;
import java.io.Serializable;




import java.util.UUID;
import java.util.Set;

@Entity
@Table(name = "clase1clasejoin")

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Clase1ClaseJoin implements Serializable {

  @Id
  @Column(name = "clase1Id", nullable = false)
  private java.util.UUID clase1Id;
  @Id
  @Column(name = "claseId", nullable = false)
  private java.util.UUID claseId;

    @ManyToOne
  @JoinColumn(name = "clase1_id", referencedColumnName = "id")
  private Clase1 clase1;

    @ManyToOne(cascade = CascadeType.MERGE)
  @JoinColumn(name = "clase_id", referencedColumnName = "id")
  private Clase clase;

    @OneToMany(mappedBy = "clase1ClaseJoin")
  private Set<Order> orders;

}
